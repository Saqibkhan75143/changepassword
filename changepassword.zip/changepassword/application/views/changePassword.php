<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div style="margin-left: 100px; margin-top: 50px;">
	<?php echo form_open('welcome/updatePwd'); ?>
	<div>
		<label>Current Password:</label><br>
		<?php echo form_password(['name'=>'password','id'=>'inputPassword','placeholder'=>'Password']); ?>
		<?php echo form_error('password','<div class="text-danger">','</div>'); ?>
	</div>
<br><br>
	<div>
		<label>New Password:</label><br>
		<?php echo form_password(['name'=>'newpass','id'=>'inputPassword','placeholder'=>'New Password']); ?>
		<?php echo form_error('newpass','<div class="text-danger">','</div>'); ?>
	</div>
<br><br>
	<div>
		<label>Confirm Password:</label><br>
		<?php echo form_password(['name'=>'confpassword','id'=>'inputPassword','placeholder'=>'Password Confirmation']); ?>
		<?php echo form_error('confpassword','<div class="text-danger">','</div>'); ?>
	</div>
<br>
	<?php echo form_submit(['name'=>'submit','value'=>'Update Password']); ?>
	<?php echo form_close(); ?>


</div>
</body>
</html>