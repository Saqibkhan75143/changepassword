<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->view('changePassword');
	}

	function updatePwd()
	{
		$this->form_validation->set_rules('password','Current Password','required|min_length[6]|max_length[20]');

		$this->form_validation->set_rules('newpass','New Password','required|min_length[6]|max_length[20]');
		
		$this->form_validation->set_rules('confpassword','Confirm Password','required|min_length[6]|max_length[20]');

		if($this->form_validation->run())
		{
			$curr_password = $this->input->post('password');

			$new_password = $this->input->post('newpass');
			
			$conf_password = $this->input->post('confpassword');
			
			$this->load->model('Queries');
			
			$userid = '1';

			$passwd = $this->Queries->getCurrPassword($userid);
			if($passwd->password == $curr_password){
				if($new_password == $conf_password){
					if($this->Queries->updatePassword($new_password,$userid)){
						echo "Password update successfully";
					}
					else{
						echo "Failled to update password";
					}

				}
				else{
					echo "New password & Confirm password is not matching.";
				}

			}
			else{
				echo "Sorry! Current password is not matching.";
			}

		}
		else
		{
			echo validation_errors();
		}
	}
}
