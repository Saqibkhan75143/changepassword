<?php 

class Queries extends CI_Model
{
	function getCurrPassword($userid)
	{
       $query = $this->db->where(['id'=> $userid])
                         ->get('tbl_users');
       if($query->num_rows() > 0){
       	  return $query->row();
       }
	}

	function updatePassword($new_password,$userid){
		$data = array(
             'password' => $new_password
		);
		return $this->db->where('id',$userid)
		          ->update('tbl_users',$data);
	}
}



?>